//
//  ViewController.swift
//  dec-7_task
//
//  Created by BJIT on 7/12/22.
//

import UIKit

protocol EditToDoDelegate{
    func editToDoData(updatedToDo: ToDo)
}


class ViewController: UIViewController {
    @IBOutlet weak var textFieldToDo: UITextField!
    @IBOutlet weak var tableViewData: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewData.dataSource = self
        tableViewData.delegate = self
        let nib = UINib(nibName: "CustomTableViewCell", bundle: nil)
        tableViewData.register(nib, forCellReuseIdentifier: "CustomTableViewCell")
        let nibHeader = UINib(nibName: "CustomHeader", bundle: nil)
        tableViewData.register(nibHeader, forHeaderFooterViewReuseIdentifier: "CustomHeader")
        let nibFooter = UINib(nibName: "CustomFooter", bundle: nil)
        tableViewData.register(nibFooter, forHeaderFooterViewReuseIdentifier: "CustomFooter")
        let nibImportantTodo = UINib(nibName: "CustomImportantTodoTableViewCell", bundle: nil)
        tableViewData.register(nibImportantTodo, forCellReuseIdentifier: "CustomImportantTodoTableViewCell")
        let nibImportantTodoHeader = UINib(nibName: "ImportantToDoListHeader", bundle: nil)
        tableViewData.register(nibImportantTodoHeader, forHeaderFooterViewReuseIdentifier: "ImportantToDoListHeader")
  
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "viewAndEditSegue"{
            if let updateToDoViewController = segue.destination as? UpdateToDoViewController{
                updateToDoViewController.loadViewIfNeeded()
                let selectedPath = tableViewData.indexPathForSelectedRow
                updateToDoViewController.toDoData = ToDo.toDoList[selectedPath!.row]
                updateToDoViewController.loadData()
                updateToDoViewController.delegate = self
                
                
            }
        }
       
    }
    @IBAction func buttonAddNewToDo(_ sender: Any) {
        if (textFieldToDo.text != ""){
            let toDo = ToDo(toDo: textFieldToDo.text!)
            ToDo.toDoList.append(toDo)
            textFieldToDo.text = ""
            tableViewData.reloadData()
        }
    }
    

}
extension ViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0 {
            let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: "CustomHeader")
            return header
        }
        if section == 1{
            let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: "ImportantToDoListHeader")
            return header
        }
        return nil
        
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footer = tableView.dequeueReusableHeaderFooterView(withIdentifier: "CustomFooter")
        return footer
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 60
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return ToDo.toDoList.count
        }
        else{
            return ToDo.importantTodoList.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let todoCell = tableView.dequeueReusableCell(withIdentifier: "CustomTableViewCell", for: indexPath) as! CustomTableViewCell
            todoCell.labelTodoText.text = ToDo.toDoList[indexPath.row].toDo
            todoCell.dateTime.text = ToDo.toDoList[indexPath.row].dateTime
            return todoCell
        }
        else{
            let todoCell = tableView.dequeueReusableCell(withIdentifier: "CustomImportantTodoTableViewCell", for: indexPath) as! CustomTableViewCell
            todoCell.labelTodoText.text = ToDo.importantTodoList[indexPath.row].toDo
            todoCell.dateTime.text = ToDo.importantTodoList[indexPath.row].dateTime
            
            return todoCell
        }
        
        
    }
    
    
}
extension ViewController: UITableViewDelegate{
//    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
//        return .delete
//    }
//    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete{
//            ToDo.toDoList.remove(at: indexPath.row)
//            tableView.beginUpdates()
//            tableView.deleteRows(at: [indexPath], with: .fade)
//            tableView.endUpdates()
//        }
//    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "viewAndEditSegue", sender: self)
    }
    
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
            let deleteAction = UIContextualAction(style: .destructive, title: nil){[weak self] _,_,_ in
                guard let self = self else{
                    return
                }
                self.handleDeleteAction(indexPath: indexPath)
            }
            deleteAction.image = UIImage(systemName: "trash")
            
            let action  = UISwipeActionsConfiguration(actions: [deleteAction])
            return action
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        if indexPath.section == 0{
            let addToImportantAction = UIContextualAction(style: .normal, title: nil){[weak self] _,_,_ in
                guard let self = self else{
                    return
                }
                self.handleAddToImportantAction(indexPath: indexPath)
            }
            addToImportantAction.image = UIImage(systemName: "star.circle.fill")
            addToImportantAction.backgroundColor = .blue
            let action  = UISwipeActionsConfiguration(actions: [addToImportantAction])
            return action
        }
        else{
            return nil
        }
    }
}


extension ViewController: EditToDoDelegate{
    func editToDoData(updatedToDo: ToDo) {
        let path = tableViewData.indexPathForSelectedRow
        if path?.section == 0{
            ToDo.toDoList[path!.row] = updatedToDo;
            tableViewData.reloadData()
        }
        if path?.section == 1{
            ToDo.importantTodoList[path!.row] = updatedToDo;
            tableViewData.reloadData()
        }
       
    }
    
    
}

extension ViewController{
    func handleDeleteAction(indexPath: IndexPath){
        if indexPath.section == 0{
            self.tableViewData.beginUpdates()
            ToDo.toDoList.remove(at: indexPath.row)
            self.tableViewData.deleteRows(at: [indexPath], with: .fade)
            self.tableViewData.endUpdates()
        }
        if indexPath.section == 1{
            self.tableViewData.beginUpdates()
            ToDo.importantTodoList.remove(at: indexPath.row)
            self.tableViewData.deleteRows(at: [indexPath], with: .fade)
            self.tableViewData.endUpdates()
        }
        
    }
    func handleAddToImportantAction(indexPath : IndexPath){
        self.tableViewData.beginUpdates()
        ToDo.importantTodoList.append(ToDo.toDoList[indexPath.row])
        self.tableViewData.reloadSections([1], with: .automatic)
        ToDo.toDoList.remove(at: indexPath.row)
        self.tableViewData.deleteRows(at: [indexPath], with: .fade)
        self.tableViewData.endUpdates()
       
    }
}
