//
//  AnimalCollectionViewCell.swift
//  dec-7_task
//
//  Created by Md. Sakibul Alam Utchas on 13/12/22.
//

import UIKit

class AnimalCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var animalImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
