//
//  UpdateToDoViewController.swift
//  dec-7_task
//
//  Created by BJIT on 9/12/22.
//

import UIKit

class UpdateToDoViewController: UIViewController {
    var toDoData: ToDo!
    var delegate: EditToDoDelegate!
    @IBOutlet weak var textAreaOfToDo: UITextView!
    @IBOutlet weak var labelToDoDate: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func updateToDoItem(_ sender: Any) {
        let toDo = ToDo(toDo: textAreaOfToDo.text)
        delegate.editToDoData(updatedToDo: toDo)
        self.dismiss(animated: true)
    }
}
extension UpdateToDoViewController{
    func loadData(){
        textAreaOfToDo.text = self.toDoData.toDo
        labelToDoDate.text = self.toDoData.dateTime
    }
}
