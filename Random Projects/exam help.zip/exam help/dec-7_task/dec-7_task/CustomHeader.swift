//
//  CustomHeader.swift
//  dec-7_task
//
//  Created by BJIT on 9/12/22.
//

import UIKit

class CustomHeader: UITableViewHeaderFooterView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
