//
//  headerFooterCollectionReusableView.swift
//  dec-7_task
//
//  Created by Md. Sakibul Alam Utchas on 14/12/22.
//

import UIKit

class headerFooterCollectionReusableView: UICollectionReusableView {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
