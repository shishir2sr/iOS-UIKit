//
//  AnimalModel.swift
//  dec-7_task
//
//  Created by Md. Sakibul Alam Utchas on 13/12/22.
//

import Foundation
struct Animal{
    var imageID: String
}

extension Animal{
    static var cats: [Animal] = [
        Animal.init(imageID: "cat1"),
        Animal.init(imageID: "cat2"),
        Animal.init(imageID: "cat3"),
        Animal.init(imageID: "cat4"),
    ]
    static var dogs: [Animal] = [
        Animal.init(imageID: "dog1"),
        Animal.init(imageID: "dog2"),
        Animal.init(imageID: "dog3"),
        Animal.init(imageID: "dog4"),
    ]
    static var birds: [Animal] = [
        Animal.init(imageID: "bird1"),
        Animal.init(imageID: "bird2"),
        Animal.init(imageID: "bird3"),
        Animal.init(imageID: "bird4"),
    ]
    static var animalList: [[Animal]] = [cats, dogs, birds]
}
