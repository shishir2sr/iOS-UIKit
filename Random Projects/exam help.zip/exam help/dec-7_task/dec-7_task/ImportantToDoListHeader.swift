//
//  ImportantToDoListHeader.swift
//  dec-7_task
//
//  Created by Md. Sakibul Alam Utchas on 11/12/22.
//

import UIKit

class ImportantToDoListHeader: UITableViewHeaderFooterView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
