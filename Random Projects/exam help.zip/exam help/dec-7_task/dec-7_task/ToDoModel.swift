//
//  AnimalModel.swift
//  dec-7_task
//
//  Created by BJIT on 7/12/22.
//

import Foundation
struct ToDo{
    var toDo: String
    var dateTime: String = "Last Updated At - " + Date().formatted()
}
extension ToDo{
    static var toDoList: [ToDo] = [
        ToDo(toDo: "Buy fruit"),
        ToDo(toDo: "Buy rice"),
        ToDo(toDo: "Study at 2.30 PM"),
        ToDo(toDo: "Go to school before 8 AM")
    ]
    static var importantTodoList: [ToDo] = [
        ToDo(toDo: "Buy fruit"),
        ToDo(toDo: "Buy rice"),
        ToDo(toDo: "Study at 2.30 PM"),
        ToDo(toDo: "Go to school before 8 AM")
    ]
}
