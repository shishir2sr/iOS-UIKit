//
//  AnimalTableViewCell.swift
//  dec-7_task
//
//  Created by Md. Sakibul Alam Utchas on 13/12/22.
//

import UIKit

class AnimalTableViewCell: UITableViewCell {
    var animalDataList: [Animal]!
    @IBOutlet weak var animalCollectionView: UICollectionView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        animalCollectionView.dataSource = self
        animalCollectionView.delegate = self
        let nib = UINib(nibName: "AnimalCollectionViewCell", bundle: nil)
        animalCollectionView.register(nib, forCellWithReuseIdentifier: "AnimalCollectionViewCell")
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        animalCollectionView.collectionViewLayout = layout
        
        let collectionNib = UINib(nibName: "headerFooterCollectionReusableView", bundle: nil)
        animalCollectionView.register(collectionNib, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "headerFooterCollectionReusableView")
        animalCollectionView.register(collectionNib, forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "headerFooterCollectionReusableView")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

extension AnimalTableViewCell: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return animalDataList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = animalCollectionView.dequeueReusableCell(withReuseIdentifier: "AnimalCollectionViewCell", for: indexPath)
        if let cell = cell as? AnimalCollectionViewCell{
            cell.animalImageView.image = UIImage(named: animalDataList[indexPath.row].imageID)
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionHeader{
            let header = animalCollectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "headerFooterCollectionReusableView", for: indexPath)
            return header
        }else{
            let footer = animalCollectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "headerFooterCollectionReusableView", for: indexPath)
            return footer
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: 100, height: 100)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: 100, height: 100)
    }
    
    
    
}
extension AnimalTableViewCell: UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        NotificationCenter.default.post(name: Notification.Name("togglePinkMode"), object: indexPath)
        //showAlert(indexPath: indexPath)
    }
    
}
extension AnimalTableViewCell: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 120, height: 180)
    }
}

extension AnimalTableViewCell{
//    func showAlert(indexPath: IndexPath){
//        let alertVC = UIAlertController(title: "Available Actions", message: "Select Actions", preferredStyle: .actionSheet)
//        let deleteAction = UIAlertAction(title: "Delete Image", style: .destructive){ [weak self]_ in
//            self?.deleteImage(indexPath: indexPath)
//        }
//        let goBackAction = UIAlertAction(title: "Go Back", style: .destructive){_ in
//            alertVC.dismiss(animated: true)
//        }
//        alertVC.addAction(deleteAction)
//        alertVC.addAction(goBackAction)
//        present(alertVC, animated: true)
//    }
//
//    func deleteImage(indexPath: IndexPath){
//        Animal.animalList[indexPath.section].remove(at: indexPath.row)
//        animalDataList.remove(at: indexPath.row)
//        animalCollectionView.reloadData()
//    }
}
