//
//  ShowAllAnimalViewController.swift
//  dec-7_task
//
//  Created by Md. Sakibul Alam Utchas on 13/12/22.
//

import UIKit

class ShowAllAnimalViewController: UIViewController {

    @IBOutlet weak var animalTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        animalTableView.dataSource = self
        animalTableView.delegate = self
        let nib = UINib(nibName: "AnimalTableViewCell", bundle: nil)
        animalTableView.register(nib, forCellReuseIdentifier: "AnimalTableViewCell")
        // Do any additional setup after loading the view.
        NotificationCenter.default.addObserver(self, selector: #selector(togglePinkMode), name: Notification.Name("togglePinkMode"), object: nil)
    }

    @objc func togglePinkMode() {
        self.view.backgroundColor = .systemBlue
        print("hello from green")
        showAlert()
    }
    deinit {
        NotificationCenter.default.removeObserver(self, name: Notification.Name("togglePinkMode"), object: nil)
    }
}

extension ShowAllAnimalViewController: UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return Animal.animalList.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = animalTableView.dequeueReusableCell(withIdentifier: "AnimalTableViewCell")
        if let cell = cell as? AnimalTableViewCell{
            cell.animalDataList = Animal.animalList[indexPath.section]
        }
        return cell!
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0{
            return "CAT"
        }
        else if section == 1{
            return "DOG"
        }
        else if section == 2{
            return "BIRD"
        }
        return nil
    }
    
    
}

extension ShowAllAnimalViewController: UITableViewDelegate{
    
}
extension ShowAllAnimalViewController{
    func showAlert(){
        let alertVC = UIAlertController(title: "Available Actions", message: "Select Actions", preferredStyle: .actionSheet)
        let deleteAction = UIAlertAction(title: "Delete Image", style: .destructive){ [weak self]_ in
            self?.deleteImage()
        }
        let goBackAction = UIAlertAction(title: "Go Back", style: .destructive){_ in
            alertVC.dismiss(animated: true)
        }
        alertVC.addAction(deleteAction)
        alertVC.addAction(goBackAction)
        present(alertVC, animated: true)
    }
    
    func deleteImage(){
        print("Deleted")
    }
}
